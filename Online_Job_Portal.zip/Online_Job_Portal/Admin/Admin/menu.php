<!-- Main menu (tabs) -->
     <div id="tabs" class="noprint">

            <h3 class="noscreen">Navigation</h3>
            <ul class="box">
                <li><a href="index.php">Home<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="User.php">User<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="ManageJob.php">Manage JobSeeker<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="ManageEmployer.php">Manage Employer<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="News.php">News<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Feedback.php">Feedback<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="session_destroy.php">Logout<span class="tab-l"></span><span class="tab-r"></span></a></li>
            </ul>

        <hr class="noscreen" />
     </div> <!-- /tabs -->